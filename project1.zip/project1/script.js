// Wait for the DOM to load
document.addEventListener("DOMContentLoaded", () => {
    // Mobile Menu Toggle
    const menuToggle = document.querySelector(".menu-toggle");
    const navMenu = document.querySelector("header nav ul");

    if (menuToggle) {
        menuToggle.addEventListener("click", () => {
            navMenu.classList.toggle("active");
            menuToggle.classList.toggle("active");
        });
    }

    // Smooth Scroll to Section
    const navLinks = document.querySelectorAll("header nav ul li a");
    navLinks.forEach(link => {
        link.addEventListener("click", e => {
            e.preventDefault();
            const targetId = link.getAttribute("href").substring(1);
            const targetSection = document.getElementById(targetId);

            if (targetSection) {
                window.scrollTo({
                    top: targetSection.offsetTop - 60,
                    behavior: "smooth",
                });
            }
        });
    });

    // Section Reveal Animation
    const sections = document.querySelectorAll("section");
    const revealSections = () => {
        const windowHeight = window.innerHeight;
        const scrollY = window.scrollY;

        sections.forEach(section => {
            const sectionTop = section.offsetTop;

            if (scrollY + windowHeight > sectionTop + 100) {
                section.classList.add("visible");
            } else {
                section.classList.remove("visible");
            }
        });
    };

    window.addEventListener("scroll", revealSections);

    // Back-to-Top Button
    const backToTopBtn = document.createElement("button");
    backToTopBtn.textContent = "↑";
    backToTopBtn.classList.add("back-to-top");
    document.body.appendChild(backToTopBtn);

    backToTopBtn.addEventListener("click", () => {
        window.scrollTo({
            top: 0,
            behavior: "smooth",
        });
    });

    const toggleBackToTop = () => {
        if (window.scrollY > 300) {
            backToTopBtn.classList.add("visible");
        } else {
            backToTopBtn.classList.remove("visible");
        }
    };

    window.addEventListener("scroll", toggleBackToTop);

    // Typewriter Animation for Heading
    const typewriter = (textElement, textArray, delay = 200) => {
        let i = 0; // Index of the current word
        let j = 0; // Index of the current character in the word

        const type = () => {
            if (j === 0) {
                // Clear the text before typing a new word
                textElement.textContent = "";
            }

            if (j < textArray[i].length) {
                textElement.textContent += textArray[i][j];
                j++;
                setTimeout(type, delay);
            } else {
                setTimeout(erase, 1500);
            }
        };

        const erase = () => {
            if (j > 0) {
                textElement.textContent = textArray[i].substring(0, j - 1);
                j--;
                setTimeout(erase, delay);
            } else {
                i = (i + 1) % textArray.length; // Move to the next word
                setTimeout(type, delay);
            }
        };

        type();
    };

    const heading = document.querySelector(".text h2 span");
    if (heading) {
        typewriter(heading, ["front-end Developer", "Designer", "Creator","web developer"], 150);
    }

    // Trigger animations on page load
    revealSections();
    toggleBackToTop();
});
