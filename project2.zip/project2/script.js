// Function to toggle extra info visibility on click
function toggleInfo(container) {
    // Toggle the active class to show/hide additional information
    container.classList.toggle('active');
}

// Smooth scrolling for navigation links
    const navLinks = document.querySelectorAll('nav ul li a');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            if (link.getAttribute('href').startsWith('#')) {
                e.preventDefault();
                const targetId = link.getAttribute('href').substring(1);
                document.getElementById(targetId).scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
// Show or hide the scroll-to-top button
window.onscroll = function () {
    if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
      document.getElementById("scrollToTopBtn").style.display = "block";
    } else {
      document.getElementById("scrollToTopBtn").style.display = "none";
    }
  };
  
  // Scroll to top functionality
  document.getElementById("scrollToTopBtn").onclick = function () {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  
  // Toggle side navigation visibility
  function toggleNav() {
    const sideNav = document.getElementById('sideNav');
    sideNav.style.display = sideNav.style.display === 'block' ? 'none' : 'block';
  }
  
  // Open different pages (home or about) in the main content area
  function openPage(page) {
    const homePage = document.getElementById('homePage');
    const aboutPage = document.getElementById('aboutPage');
    
    if (page === 'home') {
      homePage.style.display = 'block';
      aboutPage.style.display = 'none';
    } else {
      homePage.style.display = 'none';
      aboutPage.style.display = 'block';
    }
  }
  
  function rateUs(rating) {
    const stars = document.querySelectorAll('.rate-us-sidebar .star');
    const message = document.getElementById('ratingMessage');

    // Highlight stars up to the clicked one
    stars.forEach((star, index) => {
        if (index < rating) {
            star.classList.add('active');
        } else {
            star.classList.remove('active');
        }
    });

    // Display a thank-you message
    message.textContent = `Thank you for rating us ${rating} star${rating > 1 ? 's' : ''}!`;
}
