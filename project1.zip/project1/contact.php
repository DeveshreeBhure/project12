<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect the form data
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    // Your email address where the form data will be sent
    $to = "youremail@example.com"; // Replace with your email
    $subject = "New Contact Form Submission";
    
    // Email message content
    $body = "Name: $name\nEmail: $email\nMessage: $message";
    
    // Email headers
    $headers = "From: $email";

    // Send email and check if it was successful
    if (mail($to, $subject, $body, $headers)) {
        echo 'Message sent successfully!';
    } else {
        echo 'There was an error sending the message. Please try again.';
    }
}
?>
